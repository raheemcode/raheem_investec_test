﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using AnyCompany;

namespace Presentation_Raheem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

            string ConnectionString = @"Data Source=.\SQLEXPRESS;Database=Customers;User Id=sa;Password=P@ssword365;";
            DataTable customers = new DataTable();

            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Customers", connection);
            da.Fill(customers);
            cboCustomers.DataSource = customers;
            cboCustomers.DisplayMember = "Name";
            cboCustomers.ValueMember = "CustomerId";

        }

        public void ClearLoadedCustomer()
        {
            lblCustomerId.Text = "0";
            lblName.Text = "-----";
            lblCountry.Text = "-----";
            lblDOB.Text = "-----";
        }

        public void ClearOrdersGrid()
        {
            grdOrders.DataSource = null;
        }

        private void btLoad_Click(object sender, EventArgs e)
        {
            ClearLoadedCustomer();
            ClearOrdersGrid();

            Customer cust;
            cust = CustomerRepository.Load((int)cboCustomers.SelectedValue);

            lblCustomerId.Text = cust.CustomerId.ToString();
            lblName.Text = cust.Name;
            lblCountry.Text = cust.Country;
            lblDOB.Text = cust.DateOfBirth.ToShortDateString();
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            OrderForm newForm = new OrderForm();
            newForm.lblCustomerId.Text = lblCustomerId.Text;
            newForm.ShowDialog();
        }

        private void btnViewOrders_Click(object sender, EventArgs e)
        {
            string ConnectionString = @"Data Source=.\SQLEXPRESS;Database=Orders;User Id=sa;Password=P@ssword365;";
            DataTable orders = new DataTable();

            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();
            SqlCommand command = new SqlCommand("SELECT * FROM Orders WHERE CustomerId = " + lblCustomerId.Text, connection);
            SqlDataAdapter da = new SqlDataAdapter(command);
            da.Fill(orders);
            grdOrders.DataSource = orders;

        }
    }
}
    

