﻿using AnyCompany;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AnyCompany;

namespace Presentation_Raheem
{
    public partial class OrderForm : Form
    {
        public OrderForm()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            if ((txtAmount.Text != "" || txtAmount.Text != "0") && (lblCustomerId.Text != "0"))
            {
                OrderService os = new OrderService();
                Order order = new Order();
                order.CustomerId = int.Parse(lblCustomerId.Text);
                order.Amount = double.Parse(txtAmount.Text);

                bool success = os.PlaceOrder(order, order.CustomerId);
                if (success) { this.Close(); }
            }
        }
    }
}
